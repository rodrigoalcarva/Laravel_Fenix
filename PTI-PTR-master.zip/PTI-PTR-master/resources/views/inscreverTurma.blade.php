@extends('homeLayout')

@section('content')
<h1> Inscrever </h1>
<a href="/inscreverTurma"> Inscrever em turma </a>
@endsection