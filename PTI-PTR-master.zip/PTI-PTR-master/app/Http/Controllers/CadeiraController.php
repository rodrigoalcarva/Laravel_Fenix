<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cadeira;
use App\Utilizador;
use App\Docente;
use Auth;

class CadeiraController extends Controller
{
    public function getCadeira($id) {
        $cadeiraInfo = [];

        $cadeira =  Cadeira::find($id);
        
        $cadeiraInfo["docentes"] = Docente::all();
        $cadeiraInfo["cadeira"] = $cadeira;
        $cadeiraInfo["turmas"] = $cadeira->turmas->sortBy('tipo');

        $cadeiraInfo["regente"] = $cadeira->regente->utilizador->nome;

        $aulasRealizadas = $cadeira->aulasTipo->map(function ($aulaTipo) {
            return $aulaTipo->aulas;
        });

        $cadeiraInfo["aulasRealizadas"] = $aulasRealizadas;

        $cadeiraInfo["alunosSemTurma"] = $cadeira->alunos()->wherePivot('turma_pratica_id', null)->get();

        if (Auth::user()->aluno) {
            $aluno = Auth::user()->aluno;
            $alunoCadeira = $aluno->cadeiras->find($id)->pivot;

            $turmaTeorica = $alunoCadeira->turma_teorica_id;
            $turmaPratica = $alunoCadeira->turma_pratica_id;

            $cadeiraInfo["turmasAtuais"] = [$turmaTeorica, $turmaPratica];           

            $aulasAssistidas = [];
            
            foreach ($aluno->presencas as $presenca) {
                $aulasAssistidas[] = $presenca->aula;
            }

            $cadeiraInfo["aulasAssistidas"] = $aulasAssistidas;
        }

        return view('cadeira')->with($cadeiraInfo);
    } 
}
