# PTI-PTR
Projeto 3º ano de LTI

TODO:
- implementar verificar restriçoes nas salas para fazer reservas
- mestrados na factory

Perguntas para fazer:

TODO funcionalidades:
- Docente ver incompatibilidade nos alunos